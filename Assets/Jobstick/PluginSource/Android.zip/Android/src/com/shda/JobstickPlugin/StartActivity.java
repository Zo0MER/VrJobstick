package com.shda.JobstickPlugin;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import java.util.ArrayList;

/**
 * Created by Shestakov Dmitriy on 26.11.14.
 */

@SuppressLint("NewApi")
public class StartActivity extends UnityPlayerActivity
//Todo unity3d
//public class StartActivity extends Activity
{
    private static final String EVENT_MANAGER           = "JobstickEventManager";
    private static final String onBluetoothLENoFind     = "OnBluetoothLENoFind";
    private static final String onError                 = "OnError";

    protected static final String TAG = "Jobstick";
    private final static int REQUEST_ENABLE_BT = 1;

    private static StartActivity _instance;
    private boolean isInit = false;

    public BluetoothAdapter mBluetoothAdapter;
    public BluetoothManager mBluetoothManager;

    public ArrayList<JobstickPlayer> jobstickPlayers = new ArrayList<JobstickPlayer>();

    private int mMaxPlayres = 2;

    public String anglesString;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //Todo unity3d
        //setContentView(R.layout.main);

        _instance = this;

        if(!isInit)
        {
            isInit = true;
            InitBluetooch();
        }

       //StartScan();
        //Todo unity3d
       // connectButtons();
    }
    //Todo unity3d
    /*
    public void  connectButtons()
    {
        Button buttonScan = (Button)findViewById(R.id.button);

        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StartScan();
            }
        });
    }
    */
    public void SetMaxPlayers(int count)
    {
        mMaxPlayres = count;
    }

    private boolean InitBluetooch()
    {
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE))
        {
            SendMessage(onBluetoothLENoFind , "");
            return false;
        }

        if (mBluetoothManager == null)
        {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null)
            {
                SendMessageError("Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null)
        {
            SendMessageError("Unable to obtain a BluetoothAdapter.");
            SendMessage(onBluetoothLENoFind, "");
            return false;
        }

        if (!mBluetoothAdapter.isEnabled())
        {
            if (!mBluetoothAdapter.isEnabled())
            {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }

        return true;
    }

    public void BluetoothEnable()
    {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (!mBluetoothAdapter.enable())
        {
            mBluetoothAdapter.enable();
        }
    }

    public void BluetoothDisable()
    {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter.enable())
        {
            mBluetoothAdapter.disable();
        }
    }

    public boolean IsBluetoothOn()
    {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        return mBluetoothAdapter.isEnabled();
    }


    public boolean AddFindPlayer(BluetoothDevice device)
    {
        Log.d(TAG , "AddFindPlayer + " + device.getAddress());
        if(jobstickPlayers.size()  < mMaxPlayres)
        {
            for(JobstickPlayer player : jobstickPlayers)
            {
                if(player.GetAddress().equalsIgnoreCase(device.getAddress()))
                {
                    return false;
                }
            }

            JobstickPlayer player = new JobstickPlayer(device , mConnectListener);
            jobstickPlayers.add(player);

            return true;
        }

        return  false;
    }

    public JobstickPlayer.OnConnectEventListener mConnectListener = new JobstickPlayer.OnConnectEventListener()
    {
        @Override
        public void OnDisconnect(JobstickPlayer player)
        {
            StartActivity.this.jobstickPlayers.remove(player);
        }

        @Override
        public void OnConnect(JobstickPlayer player)
        {

        }
    };

    public BluetoothAdapter.LeScanCallback mLeScanCallback = new
            BluetoothAdapter.LeScanCallback()
            {

                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,byte[] scanRecord)
                {
                    //Todo unity3d
                    UnityPlayer.currentActivity.runOnUiThread(new Runnable()
                            //runOnUiThread(new Runnable()
                    {
                        @Override
                        public void run() {
                            try
                            {
                                if (device.getName().contains("Jobstick"))
                                {
                                    AddFindPlayer(device);
                                }
                            }
                            catch (Exception ex)
                            {
                              //  Log.d(TAG, ex.getMessage());
                            }
                        }
                    });
                }
            };

    public static StartActivity instance()
    {
        return _instance;
    }

    public void SendMessageError(String message)
    {
        SendMessage(onError , message);
        Log.d(TAG , message);
    }

    public static void SendMessage(String method , String param)
    {
        //Todo unity3d
        UnityPlayer.UnitySendMessage(EVENT_MANAGER , method , param );
    }

    //Unity3d calls
    public void StartScan()
    {
        StopScan();
        Log.d(TAG , "StartScan");
        mBluetoothAdapter.startLeScan(mLeScanCallback);
    }

    public void StopScan()
    {
        Log.d(TAG , "StopScan");
        mBluetoothAdapter.stopLeScan(mLeScanCallback);
    }

    public void CloseConnectionPlayer(String address)
    {
        try
        {
            for(JobstickPlayer player : jobstickPlayers)
            {
                if(player.mDevice.getAddress().equalsIgnoreCase(address))
                {
                    player.Disconnect();
                    jobstickPlayers.remove(player);
                }
            }
        }
        catch (Exception ex)
        {
        }
    }

    public void DisconnectAllPlayers()
    {
        for(JobstickPlayer player : jobstickPlayers)
        {
            if(player != null)
            {
                player.Disconnect();
            }
        }

        jobstickPlayers.clear();
    }

}
