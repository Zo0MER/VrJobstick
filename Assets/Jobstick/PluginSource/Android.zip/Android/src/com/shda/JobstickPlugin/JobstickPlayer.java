package com.shda.JobstickPlugin;

import android.bluetooth.*;
import android.os.Debug;
import android.util.Log;
import android.view.ContextThemeWrapper;

import java.util.UUID;

/**
 * Created by Shestakov Dmitriy on 26.11.14.
 */

public class JobstickPlayer extends ContextThemeWrapper
{
    public class Angless
    {
        public int ay = 0;
        public int ax = 0;
        public int az = 0;
        public int gx = 0;
        public int gy = 0;
        public int gz = 0;
    }

    public interface OnConnectEventListener
    {
        public void OnDisconnect(JobstickPlayer player);
        public void OnConnect(JobstickPlayer player);
    }

    private static final String onConnectToDevice       = "OnConnectToDevice";
    private static final String onDisconnectToDevice    = "OnDisconnectToDevice";
    private static final String onSendAngles            = "OnSendAngles";

    public BluetoothGattCharacteristic mBluetoothGattCharacteristic;

    protected static final UUID SERVICE_UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    protected static final UUID CHARACTERISTIC_UPDATE_NOTIFICATION_DESCRIPTOR_UUID = UUID.fromString("0000fff4-0000-1000-8000-00805f9b34fb");

    private byte[] data = new byte[12];


    public BluetoothDevice mDevice;
    public BluetoothGatt mBluetoothGatt;
    public OnConnectEventListener connectEventListener;

    public JobstickPlayer(BluetoothDevice device , OnConnectEventListener lisener)
    {
        /*
        getApplicationContext().registerReceiver(receiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED));

        getApplicationContext().registerReceiver(receiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED));
        */



        mDevice = device;
        connectEventListener = lisener;
        Connect();
    }

    private void Connect()
    {
        Log.d("Jobstick" , "Connect - " + mDevice.getAddress());
        mBluetoothGatt = mDevice.connectGatt(this, false, mGattCallback);
    }

    public void Disconnect()
    {
        if(mBluetoothGatt != null)
        {
            Log.d("Jobstick" , "Disconnect - " + mDevice.getAddress());

            mBluetoothGatt.disconnect();
            mBluetoothGatt.close();
            mBluetoothGatt = null;
        }
    }

    public void Reconnect()
    {
        if(mBluetoothGatt != null)
        {
            Log.d("Jobstick" , "REconnect - " + mDevice.getAddress());
           // mBluetoothGatt.connect();
           // mBluetoothGatt = mDevice.connectGatt(this, false, mGattCallback);
        }
    }

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback()
    {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status,
                                            int newState)
        {
            if(newState == BluetoothProfile.STATE_CONNECTED )
            {
                StartActivity.SendMessage(onConnectToDevice, gatt.getDevice().getAddress());
                gatt.discoverServices();

                if(connectEventListener != null)
                {
                    connectEventListener.OnConnect(JobstickPlayer.this);
                }
            }
            else if(newState == BluetoothProfile.STATE_DISCONNECTED )
            {
                StartActivity.SendMessage(onDisconnectToDevice, gatt.getDevice().getAddress());

                if(connectEventListener != null)
                {
                    connectEventListener.OnDisconnect(JobstickPlayer.this);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status)
        {
            mBluetoothGattCharacteristic = gatt.getService(SERVICE_UUID).getCharacteristic(CHARACTERISTIC_UPDATE_NOTIFICATION_DESCRIPTOR_UUID);
            gatt.setCharacteristicNotification(mBluetoothGattCharacteristic, true);
        }
        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status)
        {
            DataProcessing(characteristic);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic)
        {
            DataProcessing(characteristic);
        }

        void DataProcessing(BluetoothGattCharacteristic characteristic)
        {
            byte[] newData  = characteristic.getValue();

            int ax = GetIntFromData(newData , 0);
            int ay = GetIntFromData(newData , 2);
            int az = GetIntFromData(newData , 4);
            int gx = GetIntFromData(newData , 6);
            int gy = GetIntFromData(newData , 8);
            int gz = GetIntFromData(newData , 10);

            String anglesString = String.format("%s_%d,%d,%d,%d,%d,%d", mDevice.getAddress() ,ax,ay,az,gx,gy,gz);
            StartActivity.SendMessage(onSendAngles, anglesString);
            StartActivity.instance().anglesString = anglesString;
        }

        int GetIntFromData(byte[] array , int index)
        {
            if(array[index+1] == 127)
            {
                if(data[index+1] > 0)
                {
                    array[index+1] = 126;
                }
                else
                {
                    array[index+1] = -126;
                }
            }

            data[index] = array[index];
            data[index+1] = array[index+1];

            return array[index] + array[index+1] * 0xFF;
        }
    };

    public String GetAddress()
    {
        if(mDevice != null)
        {
            return mDevice.getAddress();
        }
        return "";
    }
}
