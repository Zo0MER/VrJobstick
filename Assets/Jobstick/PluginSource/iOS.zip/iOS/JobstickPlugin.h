/******************************************************************************
 * Created: December 2014
 * Author: Shestakov Dmitriy
 * Version: 0.1
 ******************************************************************************/

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>

@interface JobstickPlugin : NSObject <CBCentralManagerDelegate>
{
	CBCentralManager *CM;
    NSMutableDictionary* m_players;
    int m_maxPlayers;
}
@end